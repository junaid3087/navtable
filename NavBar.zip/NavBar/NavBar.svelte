<!-- Navbar.svelte -->
<script>
	import Table from "./Table.svelte";
	import { navbarVisible } from "./navbarVisibility.js";

	let showTable = false;

	function toggleTable() {
		showTable = !showTable;
		console.log("toggleTable function called. showTable:", showTable);
		navbarVisible.set(showTable); // Update the store when the table is toggled
	}

	$: {
		showTable = $navbarVisible;
	}
</script>

<div class="container">
	<div class="navbar" style="display: {$navbarVisible ? 'block' : 'none'};">
		<ul>
			<li><a on:click={toggleTable}>Users</a></li>
		</ul>
	</div>
	{#if showTable}
		<Table />
	{/if}
</div>

<style>
	:global(body) {
		background-color: white;
	}

	.container {
		display: flex;
		flex-direction: column; /* Stack elements vertically */
	}

	.navbar {
		overflow: hidden;
		background-color: #38444d;
		width: 100%;
	}

	ul {
		list-style-type: none;
		margin: 0;
		padding: 0;
	}

	li {
		float: left;
	}

	li a {
		display: inline-block;
		color: white;
		text-align: center;
		padding: 10px 16px;
		text-decoration: none;
		cursor: pointer;
	}

	li a:hover {
		background-color: red;
	}
</style>
