<script>
	let users = [
		{ email: "User1@email.com", role: "Admin", active: true },
		{ email: "User2@email.com", role: "General User", active: true },
		{ email: "User3@email.com", role: "General User", active: true },
		{ email: "User4@email.com", role: "General User", active: true },
	];

	let showModal = false;

	function openModal() {
		showModal = true;
	}

	function closeModal() {
		showModal = false;
	}

	function saveUserChanges() {
		// Retrieve and process user input if needed
		closeModal();
	}

	let passwordVisible = false;

	function togglePasswordVisibility() {
		passwordVisible = !passwordVisible;
	}
</script>

<table>
	<tr>
		<th>User</th>
		<th>Role</th>
		<th>Active</th>
		<th>Edit</th>
	</tr>
	{#each users as user (user.email)}
		<tr>
			<td>{user.email}</td>
			<td>{user.role}</td>
			<td class:active={user.active} style={user.active ? "color: green" : ""}>&#10004;</td>
			<td><button class="edit-button" on:click={openModal}>Edit</button></td>
		</tr>
	{/each}
</table>

<!-- Modal HTML -->
<div id="editModal" class="modal" style={showModal ? "display: block" : "display: none"}>
	<div class="modal-content">
		<span class="modal-header">Edit User</span>
		<label for="firstName">First Name:</label>
		<input type="text" id="firstName" value="test" />

		<label for="lastName">Last Name:</label>
		<input type="text" id="lastName" value="user" />

		<label for="username">Username:</label>
		<input type="text" id="username" value="user@email.com" />

		<label for="password">Password:</label>
		<div class="password-container">
			<input type={passwordVisible ? "text" : "password"} id="password" value="yourpassword" />
			<i
				class="{passwordVisible ? 'far fa-eye-slash' : 'far fa-eye'} password-toggle"
				on:click={togglePasswordVisibility}
				tabindex="0"
				role="button"
				aria-label="Toggle Password Visibility"
			/>
		</div>

		<div class="dropdown-container">
			<div class="dropdown">
				<label for="status">Status:</label>
				<select id="status">
					<option value="active">Active</option>
					<option value="inactive">Inactive</option>
				</select>
			</div>

			<div class="dropdown">
				<label for="type">UserType:</label>
				<select id="type">
					<option value="admin">Admin</option>
					<option value="general">General User</option>
				</select>
			</div>
		</div>

		<button on:click={closeModal}>Cancel</button>
		<button on:click={saveUserChanges}>⠀Save⠀</button>
	</div>
</div>

<style>
	table {
		border-collapse: collapse;
		width: 100%;
	}

	th,
	td {
		text-align: left;
		padding: 6px;
	}

	tr:nth-child(even) {
		background-color: #f2f2f2;
	}

	/* Modal Styles */
	.modal {
		display: none;
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background-color: rgba(0, 0, 0, 0.7);
		z-index: 1;
	}

	.modal-content {
		background-color: #fff;
		width: 600px;
		margin: auto; /* Center align horizontally */
		margin-top: 10%; /* Adjust vertical alignment as needed */
		padding: 30px;
		border-radius: 0px;
		box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
	}

	.modal-header {
		text-align: center;
		font-size: 18px;
		margin-bottom: 15px;
	}

	/* Form Styles */
	label {
		display: block;
		margin-top: 5px;
		font-weight: bold;
	}

	input[type="text"],
	input[type="password"],
	select {
		width: 100%;
		padding: 8px;
		margin-top: 5px;
		border: 2px solid #ccc;
		border-radius: 4px;
	}

	.password-container {
		position: relative;
	}

	.password-toggle {
		position: absolute;
		top: 10px;
		right: 8px;
		cursor: pointer;
	}

	button {
		margin-top: 10px;
		background-color: #4caf50;
		color: #fff;
		border: none;
		padding: 10px 15px;
		border-radius: 4px;
		cursor: pointer;
	}

	button.edit-button {
		background-color: transparent;
		color: #000;
		padding: 0;
		border: none;
		border-radius: 0;
		cursor: pointer;
	}

	/* Style for the container of Type and Status dropdowns */
	.dropdown-container {
		display: flex;
		justify-content: space-between;
	}

	/* Style for individual dropdowns */
	.dropdown {
		width: 48%;
	}
</style>
