import { writable } from "svelte/store";

export const navbarVisible = writable(false);
